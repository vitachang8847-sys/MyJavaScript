## JavaScript 訂房專案 - 洛奇營地度假村
[https://summer10920.github.io/studies_TeachDemo_JSJQ/project_Camp/final/](https://summer10920.github.io/studies_TeachDemo_JSJQ/project_Camp/final/)

## JavaScript 練習主題 - 選色器
[https://summer10920.github.io/studies_TeachDemo_JSJQ/vanillaJS/colorEditor/](https://summer10920.github.io/studies_TeachDemo_JSJQ/vanillaJS/colorEditor/)

## JavaScript 練習主題 - Cookie 廣告
[https://summer10920.github.io/studies_TeachDemo_JSJQ/vanillaJS/adCookie/](https://summer10920.github.io/studies_TeachDemo_JSJQ/vanillaJS/adCookie/)

## JavaScript 練習主題 - 故事選擇遊戲
[https://summer10920.github.io/studies_TeachDemo_JSJQ/vanillaJS/storyGame/](https://summer10920.github.io/studies_TeachDemo_JSJQ/vanillaJS/storyGame/)
[https://summer10920.github.io/studies_TeachDemo_JSJQ/vanillaJS/storyGame_swal/](https://summer10920.github.io/studies_TeachDemo_JSJQ/vanillaJS/storyGame_swal/)

## JavaScript 練習主題 - 數位鐘
[https://summer10920.github.io/studies_TeachDemo_JSJQ/vanillaJS/digiClock/](https://summer10920.github.io/studies_TeachDemo_JSJQ/vanillaJS/digiClock/)

## JavaScript 練習主題 - 類比鐘
[https://summer10920.github.io/studies_TeachDemo_JSJQ/vanillaJS/analogClock/](https://summer10920.github.io/studies_TeachDemo_JSJQ/vanillaJS/analogClock/)

## JavaScript 練習主題 - 打地鼠
[https://summer10920.github.io/studies_TeachDemo_JSJQ/vanillaJS/whackMole/](https://summer10920.github.io/studies_TeachDemo_JSJQ/vanillaJS/whackMole/)

## JQuery 練習主題 - 計時器
[https://summer10920.github.io/studies_TeachDemo_JSJQ/jQuery/timer/](https://summer10920.github.io/studies_TeachDemo_JSJQ/jQuery/timer/)